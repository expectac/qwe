from ronglian_sms_sdk import SmsSDK
import json
# accountSid = '8a216da8806f31ad0180cfa53aca16dd'
#
# # 说明：主账号Token，登陆云通讯网站后，可在控制台-应用中看到开发者主账号AUTH TOKEN
# accountToken = '03343d20e3fc47008bb69a1d8204bcf3'
#
# # 请使用管理控制台首页的APPID或自己创建应用的APPID
# appId = '8a216da8806f31ad0180cfa53bea16e4'
accId = '8aaf0708809721d00180d0c52cb30f98'
accToken = 'ccde49c9fec847808070fcc744be2d15'
appId = '8aaf0708809721d00180d0c52d890f9f'

#单列设计模式
class CCP(object):
    def __new__(cls, *args, **kwargs):
        #如果是第一次实例化，返回实例化对象，如果是第二次实例化，返回上一次实例话

        #判断是否存在类属性_instance
        if not hasattr(cls,'_instance'):
            cls._instance = super(CCP, cls).__new__(cls,*args,**kwargs)
            cls._instance.sdk = SmsSDK(accId,accToken,appId)
        return cls._instance

    def send_message(self,msilib,datas,tid):
        sdk = self._instance.sdk
        # tid = '1'
        # msilib = '13397680341'
        resp = sdk.sendMessage(tid,msilib,datas)
        result = json.loads(resp)
        if result['statusCode']=='000000':
            return 0
        else:
            return -1
if __name__ == '__main__':
    c = CCP()
    c.send_message('13281917732',('123','5'),1)
    pass