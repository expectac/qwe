__author__ = "cdtaogang"
__date__ = '2022/12/7 18:17'

# celery    配置文件
# 指定中间人
broker_url = "redis://127.0.0.1/10"