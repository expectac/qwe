__author__ = "cdtaogang"
__date__ = '2022/12/18 22:34'

from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from django.conf import settings
from . import constants


def check_access_token(openid):
    """返回明文"""
    serializer = Serializer(settings.SECRET_KEY, constants.ACCESS_TOKEN_EXPIRES)

    try:
        data = serializer.loads(openid)
    except Exception as e:
        return None
    else:
        return data.get('openid')


def generate_access_token(openid):
    """返回密文"""

    serializer = Serializer(settings.SECRET_KEY, constants.ACCESS_TOKEN_EXPIRES)

    data = {'openid':  openid}

    # 类型 是字节
    token = serializer.dumps(data)

    return token.decode()

