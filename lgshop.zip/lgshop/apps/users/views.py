from django.shortcuts import render, redirect, reverse
from django.views import View
from django import http
from .forms import RegisterForm, LoginForm
from .models import User
# from users.models import User
from django.contrib.auth import login,authenticate, logout
from utils.response_code import RETCODE
from django_redis import get_redis_connection
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.hashers import check_password
from django.contrib.auth.backends import ModelBackend
import json,re
from utils.views import LoginRequiredMixin
from django.core.mail import send_mail
from django.conf import settings
from celery_tasks.email.tasks import send_verify_email



class RegisterView(View):

    def get(self, request):
        """提供用户注册页面"""
        return render(request, 'register.html')

    def post(self, request):
        """提供用户注册逻辑"""
        # 校验参数
        register_form = RegisterForm(request.POST)

        if register_form.is_valid():
            username = register_form.cleaned_data.get('username')
            password = register_form.cleaned_data.get('password')
            mobile = register_form.cleaned_data.get('mobile')

            # 短信验证码
            sms_code_client = register_form.cleaned_data.get('sms_code')

            # 判断短信验证码输入是否正确
            redis_conn = get_redis_connection('verify_code')
            sms_code_server = redis_conn.get('sms_%s' % mobile)

            if sms_code_server.decode() is None:
                return render(request, 'register.html', {'sms_code_errmsg': '短信验证码已失效'})
            # print(sms_code_server.decode())
            # print(sms_code_client)

            if sms_code_server.decode() != sms_code_client:
                return render(request, 'register.html', {'sms_code_errmsg': '输入短信验证码有误'})

            # 保存到数据库中
            try:
                user = User.objects.create_user(username=username, password=password, mobile=mobile)
            except Exception as e:
                return render(request, 'register.html', {'register_errmsg': '注册失败'})

            # 状态保持
            login(request, user)
            # 响应结果
            # return http.HttpResponse('注册成功, 重定向到首页')
            return redirect(reverse('contents:index'))
        else:
            print(register_form.errors.get_json_data())
            context = {
                'forms_errors': register_form.errors
            }
            return render(request, 'register.html', context=context)


class UsernameCountView(View):
    """判断用户名是否重复注册"""

    def get(self, request, username):
        """
        :param username: 用户名
        :return: 返回用户名是否重复  JSON
        """

        count = User.objects.filter(username=username).count()

        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'count': count})


class MobileView(View):
    """判断手机号是否被注册"""
    def get(self,request,mobile):
        count = User.objects.filter(mobile=mobile).count()
        return http.JsonResponse({'code':RETCODE.OK,'errmsg':'OK','count':count})


class LoginView(View):
    """用户登录"""
    def get(self,request):
        return render(request, "login.html")

    def post(self,request):
        """实现登录业务
        :return:登录结果"""
        login_form = LoginForm(request.POST)
        if login_form.is_valid():
            username = login_form.cleaned_data.get("username")
            password = login_form.cleaned_data.get("password")
            remembered = login_form.cleaned_data.get("remembered")

            if not all([username,password]):
                return http.HttpResponseForbidden("缺失参数<？用户名？ 或者  ？密码？>")

        # 查询数据库是否有此用户
            #   authenticate：自带的用户认证1
            user = authenticate(username=username, password=password)
            # 用户名或者密码错误，重新返回到登录界面
            if user is None:
                return render(request,"login.html",{"errmsg":"用户名或者密码错误，请重新输入"})

            # 记住密码
            if remembered == True:
                request.session.set_expiry(None)
            else:
                request.session.set_expiry(0)

            next = request.GET.get('next')
            if next:
                response = redirect(next)
            else:
                #     为了实现在首页显示用户名，需要将用户设置到cookie中
                # response.set_cookie('key', 'valuu', 'expiry') 操控response
                response = redirect(reverse('contents:index'))

            response.set_cookie('username', user.username, max_age=3600 * 24)

            # 状态保持
            login(request,user)

            return response
        else:
            print(login_form.errors.get_json_data())
            context = {
                'forms_errors': login_form.errors
            }
            return render(request, 'login.html', context=context)


class LogoutView(View):
    """用户推出登录"""
    def get(self,request):
        logout(request)

        # 重定向
        response = redirect(reverse('contents:index'))

        # 删除cookie
        response.delete_cookie("username")

        return response


class UserInfoView(LoginRequiredMixin, View):
    """提供用户个人页面"""
    def get(self,request):
        context = {
            "username": request.user.username,
            "mobile": request.user.mobile,
            "email": request.user.email,
            "email_active": request.user.email_active,
        }
        return render(request, 'user_center_info.html', context=context)


class EmailView(LoginRequiredMixin, View):
    """添加邮箱"""
    def put(self,request):
        """接收参数"""
        json_str = request.body.decode()
        json_dict = json.loads(json_str)
        email = json_dict.get('email')

        # 校验参数
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
            return http.HttpResponseForbidden('参数邮箱有误')

        # 存数据
        try:
            request.user.email = email
            request.user.save()
        except Exception as e:
            return http.JsonResponse({'code': RETCODE.DBERR, 'errmsg': '添加邮箱失败'})

        # 发送邮箱
        verify_url = "www.baidu.com"
        send_verify_email.delay(email,verify_url)

        # 响应结果
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK'})