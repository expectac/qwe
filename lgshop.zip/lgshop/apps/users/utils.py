__author__ = "cdtaogang"
__date__ = '2022/12/8 11:35'

import re
from .models import User
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer

from django.contrib.auth.backends import ModelBackend


def get_user_by_accout(accout):
    """检验用户的手机号"""
    try:
        if re.match(r'^1[3-9]\d{9}', accout):
            user = User.objects.get(mobile=accout)
        else:
            user = User.objects.get(username=accout)
    except:
        return None
    else:
        return user

class UsernameMobileBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        """重写认证方法"""
        # 根据账号查询用户
        # 查询到用户，再检验密码
        # 密码检验完成， 返回user
        user = get_user_by_accout(username)
        if user and user.check_password(password):
            return user
        else:
            return None

def generate_verify_email_url():
    """生成邮箱激活链接"""
