__author__ = "cdtaogang"
__date__ = '2022/12/6 20:20'
# 图形验证码有效期  单位：秒
IMAGE_CODE_REDIS_EXPIRES = 300

# 短信验证码有效时间 单位：秒
SMS_CODE_REDIS_EXPIRES = 300

# 短信模板
SEND_SMS_TEMPLATE_ID = 1

# 60s内是否重复发送标记
SEND_SMS_CODE_TIMES = 60