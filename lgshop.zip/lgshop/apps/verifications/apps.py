from django.apps import AppConfig


class VerificationsConfig(AppConfig):
    name = 'verifications'
